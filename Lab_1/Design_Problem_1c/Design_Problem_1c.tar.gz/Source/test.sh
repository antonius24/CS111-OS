false; cat < yes; echo cs
echo b > yes; cat < yes; echo cs
echo c > yes; cat < yes; echo cs
echo d > yes; cat < yes; echo cs
